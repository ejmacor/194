# Claude Trader — Infra Fix Package (2026-07-17)

Prepared while you were in the air. Nothing has been pushed and nothing has
touched the Alpaca account — everything below is staged for your review.
**No strategy parameters were changed.** These fixes make the frozen v2.1
rules (day-only, flat by close, 1R max loss) actually execute.

---

## 1. WHEN YOU LAND — first 5 minutes (AEHR is naked)

AEHR: 141 shares, entry ~88.42, notional stop 81.35 — **the stop does not
exist as a live order** (day-TIF bracket expired at Wed close). It traded
through 81.35 Friday morning.

**Pick your scenario:**

**A. Landed before Fri 4:00pm ET (market open):**
1. `python manual_intervention.py` → confirm AEHR shows `NAKED`.
2. `python manual_intervention.py --flatten AEHR --reason "enforcing v2.1 day-only rule; EOD flatten failed 07-15/16"` — fills immediately. Done. Apply fixes (section 4) whenever.

**B. Landed after Fri close / weekend:**
1. **First: GitHub → Actions → "EOD Flatten" → ••• → Disable workflow.**
   The old job fires ~6:40–7:40pm ET and *cancels all open orders* — it
   will kill any stop or queued close you submit tonight. (Same reason:
   also disable "Midday Manage" until fixes are pushed — see section 2.)
2. Then either:
   - `--flatten AEHR` → close queues for Monday's open, or
   - `--rearm-stop AEHR` → GTC stop at 81.35 restored for Monday.
3. Apply fixes (section 4) before Monday, re-enable both workflows.

**C. Reading this on your phone, no laptop:** just do step B-1 (disabling
the workflows from the GitHub mobile app/site stops further damage). The
position stays as-is until you can run the script — it's paper money; the
priority is stopping the broken automation from cancelling exits.

Note: Friday's midday job may have already mechanically cut AEHR
(`MIDDAY_CUT` fires at ≤ −0.75R; it was ~−1.2R Friday morning) — **if**
cron drift let it run before 4pm. Check `logs/midday.jsonl` / your ntfy
messages. If it ran *after* 4pm, its queued close was then cancelled by
the 7pm EOD sweep — which is bug #2 below in live action.

---

## 2. ROOT CAUSE — five links

1. **Analyst wrote a swing thesis for AEHR; `SWING_ENABLED=False` (v2.1,
   07-10) silently demoted it** to DAY_MOMENTUM + day TIF. Working as
   configured, but it put a multi-day thesis on a bracket that dies at 4pm.
2. **Day-TIF bracket children expired at Wed 4:00pm** unfilled (Alpaca
   behavior — documented in run_eod.py's own docstring).
3. **GitHub cron drift ran EOD flatten ~3h late every session**
   (scheduled 19:50/19:58 UTC; every actual run 22:42–23:35 UTC = after
   the close). It has *never once* run before the bell.
4. **After hours, `close_position()` can only queue a market sell — and
   the old job's "stray order sweep" then cancelled its own close order.**
   Log printed `FLATTENED AEHR`; position survived. Twice.
5. **Thu midday manager HELD, reasoning "the bracket manages the exit"**
   — trusting an order state it never verified. The bracket was dead.

Net: a day trade carried two nights naked, through its stop, in breach of
the config's own no-overnight rule and 1R max loss.

---

## 3. WHAT'S IN THIS PACKAGE

| File | Replaces | What it does |
|---|---|---|
| `run_eod.py` | repo root | Cancels stray **buy** entries first → `flatten_all()` (server-side close+cancel) → **verifies** flat with a poll loop → never cancels sell-side orders. Logs `verified_flat` / `still_open` / `market_open_at_run` honestly (superset of old schema). `CRITICAL ... NAKED` lines land in your ntfy push. |
| `.github/workflows/eod-flatten.yml` | same path | Early cron slots (17:30 / 18:15 / 19:50 UTC) + a **sleep-until step targeting session close − 12 min**, pulled from the Alpaca calendar → immune to ~3h drift, DST-proof (no more November edits), handles 1pm early-close days. Timeout raised to 300 min for the sleep. |
| `protection_check.py` | new | Audits every open position for a live protective sell order; **re-arms a GTC stop at the stop price already logged in trade_log.csv** if missing. Fixes the "bracket manages the exit" blind spot. Wire into morning + midday workflows (block below). |
| `manual_intervention.py` | new | Read-only status audit by default; `--flatten` / `--rearm-stop` / `--flatten-all` with `--reason`. Every action appended to `logs/interventions.jsonl` so ops interventions never masquerade as strategy decisions. |

**Paste into `morning-run.yml` and `midday-manage.yml`**, as a step
*before* the analyst/manager step (same indent as existing steps):

```yaml
      - name: Protection check (verify stops exist)
        env:
          ALPACA_API_KEY: ${{ secrets.ALPACA_API_KEY }}
          ALPACA_SECRET_KEY: ${{ secrets.ALPACA_SECRET_KEY }}
        run: python protection_check.py
```

(If those workflows have a `| tee` output feeding ntfy, add
`| tee -a <that file>` so CRITICAL lines reach your phone too.)

---

## 4. HOW TO APPLY (10 min, at laptop)

1. GitHub Desktop → **pull first** (the bot commits logs constantly).
2. Copy the four files in (two replace, two new). Paste the protection
   step into the two workflow ymls.
3. Review the diffs — especially run_eod.py, since it's the safety net.
4. Commit: `infra: fix EOD flatten (cron drift + self-cancelling sweep), add protection check + ops tooling` → push.
5. Re-enable any workflows you disabled in section 1.
6. Optional dry run: Actions → EOD Flatten → "Run workflow" on a weekend —
   holiday check exits cleanly; on Monday it verifies the full path.

**Caveat:** I couldn't execute these against your Alpaca account from
here (no keys, deliberately). Everything compiles and uses only the
existing `executor.py` primitives (`flatten_all`, `close_position`,
`get_open_orders`, `_request`), but eyeball the diffs before pushing.

## 5. VERIFY (next trading day)

- Actions: EOD Flatten start time ≤ 3:48pm ET (sleep step log shows target).
- `logs/eod.jsonl` newest entry: `"verified_flat": true`, `"market_open_at_run": true`.
- ntfy push contains `EOD RESULT: VERIFIED FLAT`.
- `logs/protection.jsonl` exists after next morning run.
- Alpaca paper account: zero positions after close.

---

## 6. BOOKKEEPING (experiment integrity)

- **Tag AEHR as an infra loss, not a strategy loss.** When the evening
  review writes its realized row in `outcomes.csv`, put a note in the
  empty `reject_reason` cell: `INFRA: carried overnight 07-15/16 — EOD
  flatten failure; excluded from strategy expectancy`. Whatever it loses
  beyond the 81.35 stop is attributable to plumbing; expectancy/PF stats
  at day 90 should score it as −1R max, with the excess broken out.
- **Friday's weekly self-review (~5:40pm) is unreliable**: it read logs
  claiming the flatten succeeded, so its post-mortem was written from
  false state. Worth appending a short human correction entry to
  `journal/` (journal is memory-only, never fed to the trading model, so
  this doesn't touch the frozen run).
- **Timeline for the writeup**: v2 clock started **07-06** (not 07-03 —
  that was v1, retired). v2.1 config change (swing off, EOD flatten on)
  landed **07-10**, mid-run. AEHR (07-15) was the first day-module trade
  to test the flatten path. It failed on first contact.

## 7. NOTED, DELIBERATELY NOT CHANGED

- **Strategy/config**: zero changes. Frozen run stays frozen.
- **Challenger stays advisory** (it REJECTED AEHR at confidence 9 — its
  first strong promotion argument, but that's a day-91 decision).
- **`"mode": "shadow"` labels** in shadow_gate.py:151 / challenger.py:72,107
  are hardcoded and misleading — the gate actually blocks via
  `run_morning.py:97` (`GATE_BLOCKING=True`). Cosmetic; fix whenever.
- **`outcomes.py:230`** labels any position still open at review as
  `OPEN_SWING` even when it's a stuck day trade — that's what papered
  over AEHR. Left alone because `index.html` parses `OPEN_SWING` /
  `SWING_CLOSED`; relabeling needs a matching dashboard change.
